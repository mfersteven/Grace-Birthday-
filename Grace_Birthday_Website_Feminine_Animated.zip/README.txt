Upload index.html and the images folder to a GitHub repository, then enable GitHub Pages.
